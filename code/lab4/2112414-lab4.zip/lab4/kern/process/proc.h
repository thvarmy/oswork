#ifndef __KERN_PROCESS_PROC_H__
#define __KERN_PROCESS_PROC_H__

#include <defs.h>
#include <list.h>
#include <trap.h>
#include <memlayout.h>


// process's state in his life cycle
enum proc_state {
    PROC_UNINIT = 0,  // uninitialized
    PROC_SLEEPING,    // sleeping
    PROC_RUNNABLE,    // runnable(maybe running)
    PROC_ZOMBIE,      // almost dead, and wait parent proc to reclaim his resource
};

struct context {
    uintptr_t ra;
    uintptr_t sp;
    uintptr_t s0;
    uintptr_t s1;
    uintptr_t s2;
    uintptr_t s3;
    uintptr_t s4;
    uintptr_t s5;
    uintptr_t s6;
    uintptr_t s7;
    uintptr_t s8;
    uintptr_t s9;
    uintptr_t s10;
    uintptr_t s11;
};

#define PROC_NAME_LEN               15
#define MAX_PROCESS                 4096
#define MAX_PID                     (MAX_PROCESS * 2)

extern list_entry_t proc_list;

struct proc_struct {
    enum proc_state state;                      // Process state进程所处的状态。uCore中进程状态有四种：分别是PROC_UNINIT（未初始化）、PROC_SLEEPING（睡眠状态）、PROC_RUNNABLE（可运行状态）和PROC_ZOMBIE（僵尸状态）。这有助于内核跟踪进程的当前状态。
    int pid;                                    // Process ID进程的唯一标识符，通常是一个整数，用于在内核中唯一标识每个进程。
    int runs;                                   // the running times of Proces记录进程运行的次数，可以用来统计进程的执行情况。
    uintptr_t kstack;                           // Process kernel stack存储进程的内核栈的地址或位置。内核栈是用于执行内核代码的栈，每个进程都有自己的内核栈
    volatile bool need_resched;                 // bool value: need to be rescheduled to release CPU?标记是否需要重新调度该进程以释放CPU。当进程需要让出CPU时，内核可以根据这个标志来进行调度决策。
    struct proc_struct *parent;                 // the parent process保存了进程的父进程的指针。在内核中，只有内核创建的idle进程没有父进程，其他进程都有父进程。进程的父子关系组成了一棵进程树，
    struct mm_struct *mm;                       // Process's memory management field保存了内存管理的信息，包括内存映射，虚存管理等内容。
    struct context context;                     // Switch here to run process保存了进程执行的上下文，用于在进程切换中还原之前进程的运行状态
    struct trapframe *tf;                       // Trap frame for current interrupt保存了进程的中断帧。当进程从用户空间跳进内核空间的时候，进程的执行状态被保存在了中断帧中。系统调用可能会改变用户寄存器的值，我们可以通过调整中断帧来使得系统调用返回特定的值。
    uintptr_t cr3;                              // CR3 register: the base addr of Page Directroy Table存储CR3寄存器的值，它是页表的基址，用于管理进程的地址空间。
    uint32_t flags;                             // Process flag存储一些与进程相关的标志或标识信息。
    char name[PROC_NAME_LEN + 1];               // Process name进程的名称，通常是一个字符串，用于标识进程的名字。
    list_entry_t list_link;                     // Process link list 将进程添加到不同的链表中，以进行进程调度和管理。双向链表；将 struct proc_struct 连接成一个链表，所有进程控制块
    list_entry_t hash_link;                     // Process hash list连接进程控制块
};

#define le2proc(le, member)         \
    to_struct((le), struct proc_struct, member)

extern struct proc_struct *idleproc, *initproc, *current;

void proc_init(void);
void proc_run(struct proc_struct *proc);
int kernel_thread(int (*fn)(void *), void *arg, uint32_t clone_flags);

char *set_proc_name(struct proc_struct *proc, const char *name);
char *get_proc_name(struct proc_struct *proc);
void cpu_idle(void) __attribute__((noreturn));

struct proc_struct *find_proc(int pid);
int do_fork(uint32_t clone_flags, uintptr_t stack, struct trapframe *tf);
int do_exit(int error_code);

#endif /* !__KERN_PROCESS_PROC_H__ */

