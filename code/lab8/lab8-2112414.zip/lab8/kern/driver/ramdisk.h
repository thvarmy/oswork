#include <ide.h>

void ramdisk_init(int devno, struct ide_device *dev);
